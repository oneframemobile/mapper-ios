//
//  Mapper.h
//  Mapper
//
//  Created by Gökhan Alp on 11.11.2019.
//  Copyright © 2019 KocSistem. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Mapper.
FOUNDATION_EXPORT double MapperVersionNumber;

//! Project version string for Mapper.
FOUNDATION_EXPORT const unsigned char MapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mapper/PublicHeader.h>


